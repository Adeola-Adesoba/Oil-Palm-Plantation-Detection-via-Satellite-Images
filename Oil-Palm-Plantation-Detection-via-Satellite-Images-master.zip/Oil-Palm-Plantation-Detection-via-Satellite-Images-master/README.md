# Oil-Palm-Plantation-Detection-via-Satellite-Images
This notebook provides image classification work on satellite images using transfer learning approach
